package alararestaurant.service;

public interface CategoryService {

    String exportCategoriesByCountOfItems();
}
